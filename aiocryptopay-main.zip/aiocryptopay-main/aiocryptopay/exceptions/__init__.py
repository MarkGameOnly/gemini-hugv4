from .factory import CodeErrorFactory


"""
Docs https://help.crypt.bot/crypto-pay-api
"""

CryptoPayAPIError = CodeErrorFactory()
